export enum MazeTileType {
  Start = 0,
  End = 1,
  Path = 2,
  Empty = 3
}
