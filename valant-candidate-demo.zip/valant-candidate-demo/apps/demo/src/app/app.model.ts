export type Stuff = Record<string, unknown>;
