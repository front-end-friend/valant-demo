module.exports = {
  projects: ['<rootDir>/apps/demo'],
};
