namespace ValantDemoApi.Services {
  public enum Direction {
    Up,
    Down,
    Left,
    Right
  }
}
