using Microsoft.AspNetCore.Mvc.Testing;

namespace ValantDemoApi.Tests
{
  public class APIWebApplicationFactory : WebApplicationFactory<Startup>
  {
  }
}
